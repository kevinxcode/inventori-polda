#
# TABLE STRUCTURE FOR: master_pengadaan
#

DROP TABLE IF EXISTS `master_pengadaan`;

CREATE TABLE `master_pengadaan` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `judul_pengadaan` text NOT NULL,
  `tahun` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `master_pengadaan` (`id`, `judul_pengadaan`, `tahun`) VALUES (1, 'PENGADAAN BARANG / JASA MATERIL MIS INTELKAM T.A 2011', '2011');


#
# TABLE STRUCTURE FOR: tb_peralatan
#

DROP TABLE IF EXISTS `tb_peralatan`;

CREATE TABLE `tb_peralatan` (
  `id_peralatan` int(10) NOT NULL AUTO_INCREMENT,
  `pengadaan` text NOT NULL,
  `jenis` text NOT NULL,
  `jumlah` varchar(20) NOT NULL,
  `b` varchar(20) NOT NULL,
  `rr` varchar(20) NOT NULL,
  `rb` varchar(20) NOT NULL,
  PRIMARY KEY (`id_peralatan`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tb_peralatan` (`id_peralatan`, `pengadaan`, `jenis`, `jumlah`, `b`, `rr`, `rb`) VALUES (4, '1', 'aaaa', '2', '3', '1', '4');


#
# TABLE STRUCTURE FOR: tb_pinjaman
#

DROP TABLE IF EXISTS `tb_pinjaman`;

CREATE TABLE `tb_pinjaman` (
  `id_pinjaman` int(15) NOT NULL AUTO_INCREMENT,
  `tanggal_pinjam` date NOT NULL,
  `nama_barang` text NOT NULL,
  `peminjam` varchar(45) NOT NULL,
  `jumlah` varchar(20) NOT NULL,
  `tanggal_kembali` date NOT NULL,
  PRIMARY KEY (`id_pinjaman`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tb_pinjaman` (`id_pinjaman`, `tanggal_pinjam`, `nama_barang`, `peminjam`, `jumlah`, `tanggal_kembali`) VALUES (2, '2023-06-29', 'aaaa', 'ddas', '1', '2023-06-29');


#
# TABLE STRUCTURE FOR: tb_user
#

DROP TABLE IF EXISTS `tb_user`;

CREATE TABLE `tb_user` (
  `idUser` int(10) NOT NULL AUTO_INCREMENT,
  `token_user` text NOT NULL,
  `name` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` text NOT NULL,
  `level` int(5) NOT NULL,
  PRIMARY KEY (`idUser`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `tb_user` (`idUser`, `token_user`, `name`, `username`, `password`, `level`) VALUES (1, 'Tasdasodjp32432464Gasdoewrdjjdisj', 'Admin', 'admin', '0cc175b9c0f1b6a831c399e269772661', 1);


